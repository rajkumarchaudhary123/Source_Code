package com.file.rest.payload;

public class FileDBDummy {
    
}
