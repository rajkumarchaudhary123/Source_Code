package com.file.rest;

public class FileDemoApplicationTests {


	public void contextLoads() {
	}

}
